package warble.project.com.warbleandroid.Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import warble.project.com.warbleandroid.R;

public class ProfileVideosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_videos);

    }
}
