package warble.project.com.warbleandroid.Activities;

import android.graphics.Bitmap;

class VideoViewInfo {
    String filePath;
    String mimeType;
    Bitmap thumbPath;
    String title;
}
